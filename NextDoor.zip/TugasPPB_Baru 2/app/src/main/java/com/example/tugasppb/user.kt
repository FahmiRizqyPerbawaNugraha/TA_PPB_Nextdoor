package com.example.tugasppb

data class User(val id: Int, val username: String, val password: String)
